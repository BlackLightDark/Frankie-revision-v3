// Frankie timetable v3 — cleaned exam timetable duplication and kept v2 UX upgrades
// ─── DATA ───────────────────────────────────────────────────────────────────

const weeks = [
  {
    label: "30 Mar \u2013 5 Apr",
    type: "easter",
    days: [
      { day: "Mon", date: "30 Mar", tasks: [{"text": "After school Maths", "subj": "maths", "special": "school", "src": "original"}], period: "school", inRange: true },
      { day: "Tue", date: "31 Mar", tasks: [{"text": "After school Art", "subj": "art", "special": "school", "src": "original"}], period: "school", inRange: true },
      { day: "Wed", date: "1 Apr", tasks: [{"text": "Macbeth quotes revision", "subj": "macbeth", "src": "holiday"}], period: "easter", inRange: true },
      { day: "Thu", date: "2 Apr", tasks: [{"text": "Art (in school)", "subj": "art", "special": "school", "src": "original"}], period: "easter", inRange: true },
      { day: "Fri", date: "3 Apr", tasks: [{"text": "Macbeth with Mum", "subj": "macbeth", "special": "special", "src": "original"}], period: "easter", inRange: true },
      { day: "Sat", date: "4 Apr", tasks: [{"text": "Biology Paper 1 flashcards", "subj": "bio", "src": "holiday"}], period: "easter", inRange: true },
      { day: "Sun", date: "5 Apr", tasks: [{"text": "Biology Paper 1 sit paper", "subj": "bio", "src": "holiday"}, {"text": "Flashcards for poetry", "subj": "lit", "src": "holiday"}], period: "easter", inRange: true }
    ]
  },
  {
    label: "6 Apr \u2013 12 Apr",
    type: "easter",
    days: [
      { day: "Mon", date: "6 Apr", tasks: [{"text": "English Lit Paper 1 – Poetry practice Q", "subj": "lit", "src": "holiday"}], period: "easter", inRange: true },
      { day: "Tue", date: "7 Apr", tasks: [{"text": "Geography Paper 1 revision", "subj": "geog", "src": "holiday"}, {"text": "Haircut", "subj": "default", "special": "special", "src": "original"}], period: "easter", inRange: true },
      { day: "Wed", date: "8 Apr", tasks: [{"text": "Geography – practice paper", "subj": "geog", "src": "holiday"}, {"text": "Art", "subj": "art", "src": "holiday"}], period: "easter", inRange: true },
      { day: "Thu", date: "9 Apr", tasks: [{"text": "Art day", "subj": "art", "special": "school", "src": "original"}], period: "easter", inRange: true },
      { day: "Fri", date: "10 Apr", tasks: [{"text": "History – Migrants", "subj": "history", "src": "holiday"}, {"text": "Practice Paper", "subj": "default", "src": "holiday"}], period: "easter", inRange: true },
      { day: "Sat", date: "11 Apr", tasks: [{"text": "Geography Paper 2 – Pinpoint", "subj": "geog", "src": "holiday"}, {"text": "Physics Paper 1 cards", "subj": "physics", "src": "holiday"}], period: "easter", inRange: true },
      { day: "Sun", date: "12 Apr", tasks: [{"text": "English Lit Paper 2", "subj": "lit", "src": "holiday"}, {"text": "P&H / ACC / Unseen sit paper", "subj": "lit", "src": "holiday"}], period: "easter", inRange: true }
    ]
  },
  {
    label: "13 Apr \u2013 19 Apr",
    type: "easter",
    days: [
      { day: "Mon", date: "13 Apr", tasks: [], period: "easter", inRange: true },
      { day: "Tue", date: "14 Apr", tasks: [], period: "easter", inRange: true },
      { day: "Wed", date: "15 Apr", tasks: [{"text": "School – Music Composition", "subj": "music", "special": "school", "src": "original"}], period: "easter", inRange: true },
      { day: "Thu", date: "16 Apr", tasks: [{"text": "Chemistry Paper 1 – complete", "subj": "chem", "src": "holiday"}, {"text": "Pinpoint", "subj": "default", "src": "holiday"}], period: "easter", inRange: true },
      { day: "Fri", date: "17 Apr", tasks: [{"text": "Chemistry with Sam", "subj": "chem", "special": "special", "src": "original"}, {"text": "Biology flashcards", "subj": "bio", "src": "holiday"}], period: "easter", inRange: true },
      { day: "Sat", date: "18 Apr", tasks: [{"text": "School – Music Composition", "subj": "music", "special": "school", "src": "original"}], period: "easter", inRange: true },
      { day: "Sun", date: "19 Apr", tasks: [{"text": "Geography day", "subj": "geog", "src": "holiday"}, {"text": "Art presenting", "subj": "art", "src": "holiday"}], period: "easter", inRange: true }
    ]
  },
  {
    label: "20 Apr \u2013 26 Apr",
    type: "school",
    days: [
      { day: "Mon", date: "20 Apr", tasks: [{"text": "English Lang Paper 1", "subj": "english", "src": "holiday"}, {"text": "Physics Paper 1 sit", "subj": "physics", "src": "holiday"}], period: "school", inRange: true },
      { day: "Tue", date: "21 Apr", tasks: [{"text": "History (Middle East / Elizabethan)", "subj": "history", "src": "holiday"}], period: "school", inRange: true },
      { day: "Wed", date: "22 Apr", tasks: [{"text": "Physics Paper 1 flashcards", "subj": "physics", "src": "original"}, {"text": "Sit paper", "subj": "physics", "src": "original"}], period: "school", inRange: true },
      { day: "Thu", date: "23 Apr", tasks: [{"text": "Pinpoint", "subj": "default", "src": "original"}, {"text": "Paper 2 Geography", "subj": "geog", "src": "original"}], period: "school", inRange: true },
      { day: "Fri", date: "24 Apr", tasks: [], period: "school", inRange: true },
      { day: "Sat", date: "25 Apr", tasks: [{"text": "School day", "subj": "default", "special": "school", "src": "added"}, {"text": "History (ME & Elizabethan) evening", "subj": "history", "src": "added"}], period: "school", inRange: true },
      { day: "Sun", date: "26 Apr", tasks: [{"text": "Sit English Lang Paper 2", "subj": "english", "src": "original"}, {"text": "Bio paper 2 flashcards", "subj": "bio", "src": "original"}], period: "school", inRange: true }
    ]
  },
  {
    label: "27 Apr \u2013 3 May",
    type: "school",
    days: [
      { day: "Mon", date: "27 Apr", tasks: [{"text": "Music Listening revision", "subj": "music", "src": "original"}, {"text": "Bio Paper 2 sit paper", "subj": "bio", "src": "original"}], period: "school", inRange: true },
      { day: "Tue", date: "28 Apr", tasks: [{"text": "School day", "subj": "default", "special": "school", "src": "added"}, {"text": "Evening: History USA – Pinpoint", "subj": "history", "src": "added"}], period: "school", inRange: true },
      { day: "Wed", date: "29 Apr", tasks: [{"text": "School day", "subj": "default", "special": "school", "src": "added"}, {"text": "Evening: Geog Paper 3 pre-release", "subj": "geog", "src": "added"}], period: "school", inRange: true },
      { day: "Thu", date: "30 Apr", tasks: [{"text": "School day", "subj": "default", "special": "school", "src": "added"}, {"text": "Evening: Chem Paper 2 review", "subj": "chem", "src": "added"}], period: "school", inRange: true },
      { day: "Fri", date: "1 May", tasks: [{"text": "School day", "subj": "default", "special": "school", "src": "added"}, {"text": "Evening: Physics Paper 2 equations", "subj": "physics", "src": "added"}], period: "school", inRange: true },
      { day: "Sat", date: "2 May", tasks: [{"text": "School day", "subj": "default", "special": "school", "src": "added"}, {"text": "Evening: Lit Paper 2 unseen practice", "subj": "lit", "src": "added"}], period: "school", inRange: true },
      { day: "Sun", date: "3 May", tasks: [{"text": "Chemistry Paper 2", "subj": "chem", "src": "original"}], period: "school", inRange: true }
    ]
  },
  {
    label: "4 May \u2013 10 May",
    type: "school",
    days: [
      { day: "Mon", date: "4 May", tasks: [{"text": "Physics Paper 2 sit paper", "subj": "physics", "src": "original"}], period: "school", inRange: true },
      { day: "Tue", date: "5 May", tasks: [{"text": "Bank Holiday", "subj": "default", "special": "special", "src": "added"}, {"text": "Final light revision", "subj": "default", "src": "added"}], period: "school", inRange: true },
      { day: "Wed", date: "6 May", tasks: [{"text": "School day", "subj": "default", "special": "school", "src": "added"}], period: "school", inRange: true },
      { day: "Thu", date: "7 May", tasks: [{"text": "⚠️ English Language Spoken (TBC)", "subj": "english", "special": "special", "src": "added"}], period: "school", inRange: true },
      { day: "Fri", date: "8 May", tasks: [{"text": "School day", "subj": "default", "special": "school", "src": "added"}], period: "school", inRange: true },
      { day: "Sat", date: "9 May", tasks: [{"text": "School day", "subj": "default", "special": "school", "src": "added"}], period: "school", inRange: true },
      { day: "Sun", date: "10 May", tasks: [{"text": "Light revision – rest focus", "subj": "default", "src": "added"}], period: "school", inRange: true }
    ]
  },
  {
    label: "11 May \u2013 17 May",
    type: "school",
    days: [
      { day: "Mon", date: "11 May", tasks: [{"text": "Final prep: Lit Paper 1", "subj": "lit", "src": "added"}], period: "school", inRange: true },
      { day: "Tue", date: "12 May", tasks: [{"text": "⚠️ English Lit Paper 1 09:00", "subj": "lit", "special": "special", "src": "added"}], period: "school", inRange: true },
      { day: "Wed", date: "13 May", tasks: [{"text": "⚠️ Biology Paper 1 13:30", "subj": "bio", "special": "special", "src": "added"}], period: "school", inRange: true },
      { day: "Thu", date: "14 May", tasks: [{"text": "⚠️ Geography Paper 1 09:00", "subj": "geog", "special": "special", "src": "added"}], period: "school", inRange: true },
      { day: "Fri", date: "15 May", tasks: [{"text": "⚠️ Maths Non-Calc 09:00", "subj": "maths", "special": "special", "src": "added"}], period: "school", inRange: true },
      { day: "Sat", date: "16 May", tasks: [{"text": "⚠️ Music Performing & Composing", "subj": "music", "special": "special", "src": "added"}, {"text": "⚠️ History Migrants 09:00", "subj": "history", "special": "special", "src": "added"}], period: "school", inRange: true },
      { day: "Sun", date: "17 May", tasks: [{"text": "Rest & recover", "subj": "default", "src": "added"}], period: "school", inRange: true }
    ]
  },
  {
    label: "18 May \u2013 24 May",
    type: "school",
    days: [
      { day: "Mon", date: "18 May", tasks: [{"text": "Evening: Chem Paper 1 final review", "subj": "chem", "src": "added"}], period: "school", inRange: true },
      { day: "Tue", date: "19 May", tasks: [{"text": "⚠️ Chemistry Paper 1 09:00", "subj": "chem", "special": "special", "src": "added"}], period: "school", inRange: true },
      { day: "Wed", date: "20 May", tasks: [{"text": "⚠️ English Lit Paper 2 09:00", "subj": "lit", "special": "special", "src": "added"}], period: "school", inRange: true },
      { day: "Thu", date: "21 May", tasks: [{"text": "⚠️ English Language Paper 1 09:00", "subj": "english", "special": "special", "src": "added"}], period: "school", inRange: true },
      { day: "Fri", date: "22 May", tasks: [], period: "school", inRange: true },
      { day: "Sat", date: "23 May", tasks: [{"text": "Physics Paper 1 flashcards", "subj": "physics", "src": "original"}, {"text": "Sit paper", "subj": "physics", "src": "original"}], period: "halfterm2", inRange: true },
      { day: "Sun", date: "24 May", tasks: [{"text": "Pinpoint", "subj": "default", "src": "original"}, {"text": "Paper 2 Geography", "subj": "geog", "src": "original"}], period: "halfterm2", inRange: true }
    ]
  },
  {
    label: "25 May \u2013 31 May",
    type: "halfterm2",
    days: [
      { day: "Mon", date: "25 May", tasks: [{"text": "History (Middle East & Elizabethan)", "subj": "history", "src": "original"}, {"text": "Past Paper questions", "subj": "default", "src": "original"}], period: "halfterm2", inRange: true },
      { day: "Tue", date: "26 May", tasks: [{"text": "Sit English Lang Paper 2", "subj": "english", "src": "original"}, {"text": "Bio paper 2 flashcards", "subj": "bio", "src": "original"}], period: "halfterm2", inRange: true },
      { day: "Wed", date: "27 May", tasks: [{"text": "Music Listening revision", "subj": "music", "src": "original"}, {"text": "Bio Paper 2 sit paper", "subj": "bio", "src": "original"}], period: "halfterm2", inRange: true },
      { day: "Thu", date: "28 May", tasks: [{"text": "History USA – Pinpoint", "subj": "history", "src": "original"}], period: "halfterm2", inRange: true },
      { day: "Fri", date: "29 May", tasks: [{"text": "Geography Paper 3 pre-release", "subj": "geog", "src": "original"}], period: "halfterm2", inRange: true },
      { day: "Sat", date: "30 May", tasks: [{"text": "Chemistry Paper 2", "subj": "chem", "src": "original"}], period: "halfterm2", inRange: true },
      { day: "Sun", date: "31 May", tasks: [{"text": "Physics Paper 2", "subj": "physics", "src": "original"}, {"text": "Revise Paper 1 & practice papers", "subj": "physics", "src": "original"}], period: "halfterm2", inRange: true }
    ]
  },
  {
    label: "1 Jun \u2013 7 Jun",
    type: "exam",
    days: [
      { day: "Mon", date: "1 Jun", tasks: [{"text": "Final prep: Physics Paper 1", "subj": "physics", "src": "added"}], period: "exam", inRange: true },
      { day: "Tue", date: "2 Jun", tasks: [{"text": "⚠️ Physics Paper 1 09:00", "subj": "physics", "special": "special", "src": "added"}], period: "exam", inRange: true },
      { day: "Wed", date: "3 Jun", tasks: [{"text": "⚠️ Maths Calculator 09:00", "subj": "maths", "special": "special", "src": "added"}, {"text": "⚠️ Geography Paper 2 13:30", "subj": "geog", "special": "special", "src": "added"}], period: "exam", inRange: true },
      { day: "Thu", date: "4 Jun", tasks: [{"text": "⚠️ History: ME & Elizabethan 09:00", "subj": "history", "special": "special", "src": "added"}], period: "exam", inRange: true },
      { day: "Fri", date: "5 Jun", tasks: [{"text": "⚠️ English Language Paper 2 09:00", "subj": "english", "special": "special", "src": "added"}, {"text": "⚠️ Music Appraising 13:30", "subj": "music", "special": "special", "src": "added"}], period: "exam", inRange: true },
      { day: "Sat", date: "6 Jun", tasks: [], period: "exam", inRange: true },
      { day: "Sun", date: "7 Jun", tasks: [{"text": "Final prep: Bio Paper 2", "subj": "bio", "src": "added"}], period: "exam", inRange: true }
    ]
  },
  {
    label: "8 Jun \u2013 14 Jun",
    type: "exam",
    days: [
      { day: "Mon", date: "8 Jun", tasks: [], period: "exam", inRange: true },
      { day: "Tue", date: "9 Jun", tasks: [{"text": "⚠️ Biology Paper 2 09:00", "subj": "bio", "special": "special", "src": "added"}], period: "exam", inRange: true },
      { day: "Wed", date: "10 Jun", tasks: [{"text": "⚠️ History USA 13:30", "subj": "history", "special": "special", "src": "added"}], period: "exam", inRange: true },
      { day: "Thu", date: "11 Jun", tasks: [{"text": "⚠️ Maths Calculator H 09:00", "subj": "maths", "special": "special", "src": "added"}], period: "exam", inRange: true },
      { day: "Fri", date: "12 Jun", tasks: [{"text": "⚠️ Geography Paper 3 09:00", "subj": "geog", "special": "special", "src": "added"}], period: "exam", inRange: true },
      { day: "Sat", date: "13 Jun", tasks: [{"text": "⚠️ Chemistry Paper 2 09:00", "subj": "chem", "special": "special", "src": "added"}], period: "exam", inRange: true },
      { day: "Sun", date: "14 Jun", tasks: [], period: "exam", inRange: true }
    ]
  },
  {
    label: "15 Jun – 21 Jun",
    type: "exam",
    days: [
      { day: "Mon", date: "15 Jun", tasks: [{"text": "⚠️ Physics Paper 2 09:00 🎉 LAST EXAM!", "subj": "physics", "special": "special", "src": "added"}], period: "exam", inRange: true },
      { day: "Tue", date: "16 Jun", tasks: [], period: "normal", inRange: true },
      { day: "Wed", date: "17 Jun", tasks: [], period: "normal", inRange: true },
      { day: "Thu", date: "18 Jun", tasks: [], period: "normal", inRange: true },
      { day: "Fri", date: "19 Jun", tasks: [], period: "normal", inRange: true },
      { day: "Sat", date: "20 Jun", tasks: [], period: "normal", inRange: true },
      { day: "Sun", date: "21 Jun", tasks: [], period: "normal", inRange: true }
    ]
  }
];






const examsBefore = [
  "Art exam",
  "Lit Paper 1 – Mac and Poetry",
  "Bio Paper 1",
  "Geog Paper 1",
  "Maths Paper 1",
  "History Migrants",
  "Chem Paper 1",
  "Lit Paper 2 – ACC, P&H and Unseen",
  "English Lang Paper 1"
];

const examsAfter = [
  "Physics Paper 1",
  "Maths (calc)",
  "Geog Paper 2",
  "History (Middle East and Elizabethan)",
  "English Lang Paper 2",
  "Music Listening",
  "Bio Paper 2",
  "History USA",
  "Maths Paper 3",
  "Geog Paper 3",
  "Chem Paper 2",
  "Physics Paper 2"
];

// ─── STATE ──────────────────────────────────────────────────────────────────

let state = JSON.parse(localStorage.getItem('frankie_state') || '{"tasks":{},"exams":{}}');
let activeFilter = 'all';
let hideCompleted = false;

function saveState() {
  localStorage.setItem('frankie_state', JSON.stringify(state));
}

function taskKey(weekIdx, dayIdx, taskIdx) {
  return `w${weekIdx}d${dayIdx}t${taskIdx}`;
}

function examKey(list, idx) {
  return `exam_${list}_${idx}`;
}

// ─── RENDER ─────────────────────────────────────────────────────────────────

function subjClass(subj) {
  const map = {
    maths: 'subj-maths', english: 'subj-english', lit: 'subj-lit',
    bio: 'subj-bio', chem: 'subj-chem', physics: 'subj-physics',
    history: 'subj-history', geog: 'subj-geog', art: 'subj-art',
    music: 'subj-music', macbeth: 'subj-macbeth', default: 'subj-default'
  };
  return map[subj] || 'subj-default';
}


function parseCalendarDate(dateStr) {
  const monMap = {Jan:0,Feb:1,Mar:2,Apr:3,May:4,Jun:5,Jul:6,Aug:7,Sep:8,Oct:9,Nov:10,Dec:11};
  const [dayNum, mon] = dateStr.split(' ');
  return new Date(2026, monMap[mon], parseInt(dayNum, 10));
}

function getAllTaskEntries() {
  const entries = [];
  weeks.forEach((week, wi) => {
    week.days.forEach((day, di) => {
      if (!day.inRange) return;
      day.tasks.forEach((task, ti) => {
        entries.push({
          week,
          weekIndex: wi,
          day,
          dayIndex: di,
          task,
          taskIndex: ti,
          key: taskKey(wi, di, ti),
          dateObj: parseCalendarDate(day.date),
          done: !!state.tasks[taskKey(wi, di, ti)]
        });
      });
    });
  });
  return entries;
}

function getVisibleEntries() {
  return getAllTaskEntries().filter(entry => {
    const matchesSubject = activeFilter === 'all' || entry.task.subj === activeFilter;
    const matchesDone = !hideCompleted || !entry.done;
    return matchesSubject && matchesDone;
  });
}

function getVisibleTasksForDay(wi, di) {
  const day = weeks[wi].days[di];
  return day.tasks
    .map((task, ti) => ({
      task,
      taskIndex: ti,
      key: taskKey(wi, di, ti),
      done: !!state.tasks[taskKey(wi, di, ti)]
    }))
    .filter(item => {
      const matchesSubject = activeFilter === 'all' || item.task.subj === activeFilter;
      const matchesDone = !hideCompleted || !item.done;
      return matchesSubject && matchesDone;
    })
    .sort((a, b) => Number(a.done) - Number(b.done));
}

function renderTimetable() {
  const container = document.getElementById('weeks-container');
  container.innerHTML = '';

  const today = new Date(); today.setHours(0,0,0,0);

  const headerRow = document.createElement('div');
  headerRow.className = 'cal-header-row';
  headerRow.style.cssText = 'display:grid;grid-template-columns:100px repeat(7,1fr);gap:4px;margin-bottom:4px;position:sticky;top:0;z-index:10;background:var(--bg);padding-bottom:2px;';
  headerRow.innerHTML = '<div></div>' + ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d =>
    `<div style="text-align:center;font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;color:var(--ink-light);padding:4px 0;">${d}</div>`
  ).join('');
  container.appendChild(headerRow);

  const typeStyles = {
    easter:   { bg: '#fef9ee', border: '#fcd34d', badge: '🐣 Easter',    badgeBg: '#fef3e2', badgeColor: '#92400e' },
    halfterm: { bg: '#fdf8e3', border: '#f5c842', badge: '🏖 Half Term', badgeBg: '#fdf8e3', badgeColor: '#7a5800' },
    halfterm2:{ bg: '#fdf8e3', border: '#f5c842', badge: '🏖 Half Term', badgeBg: '#fdf8e3', badgeColor: '#7a5800' },
    school:   { bg: '#f5f8ff', border: '#c3d4fa', badge: '🏫 School',    badgeBg: '#e8f0fe', badgeColor: '#1a3a8a' },
    exam:     { bg: '#fff5f5', border: '#fca5a5', badge: '📝 Exams',     badgeBg: '#fee2e2', badgeColor: '#991b1b' },
    normal:   { bg: 'white',   border: 'var(--border)', badge: '', badgeBg: '', badgeColor: '' },
  };

  weeks.forEach((week, wi) => {
    const ts = typeStyles[week.type] || typeStyles.normal;

    let totalTasks = 0, doneTasks = 0;
    week.days.forEach((d, di) => {
      getVisibleTasksForDay(wi, di).forEach(item => {
        totalTasks++;
        if (item.done) doneTasks++;
      });
    });

    const weekRow = document.createElement('div');
    weekRow.className = 'cal-week-row';
    weekRow.style.cssText = 'display:grid;grid-template-columns:100px repeat(7,1fr);gap:4px;margin-bottom:4px;align-items:stretch;';

    const labelCell = document.createElement('div');
    labelCell.className = 'cal-label-cell';
    labelCell.style.cssText = `
      background:${ts.bg};
      border:1.5px solid ${ts.border};
      border-radius:8px;
      padding:8px 6px;
      display:flex;
      flex-direction:column;
      justify-content:center;
      gap:4px;
    `;
    labelCell.innerHTML = `
      <div style="font-size:0.65rem;font-weight:700;color:var(--ink);line-height:1.3;">${week.label}</div>
      ${ts.badge ? `<span style="font-size:0.58rem;background:${ts.badgeBg};color:${ts.badgeColor};padding:1px 5px;border-radius:4px;font-weight:600;display:inline-block;">${ts.badge}</span>` : ''}
      ${totalTasks > 0 ? `<div class="cal-task-count" style="font-size:0.6rem;color:var(--ink-light);">${doneTasks}/${totalTasks}</div>` : '<div class="cal-task-count" style="font-size:0.6rem;color:var(--border);">—</div>'}
    `;
    weekRow.appendChild(labelCell);

    const daysCol = document.createElement('div');
    daysCol.className = 'cal-days-col';
    daysCol.style.cssText = 'display:contents;';
    weekRow.appendChild(daysCol);

    week.days.forEach((d, di) => {
      const cell = document.createElement('div');
      const cellDate = parseCalendarDate(d.date);
      const isToday = cellDate.getTime() === today.getTime();
      const isPast  = cellDate < today;
      const visibleTasks = d.inRange ? getVisibleTasksForDay(wi, di) : [];

      if (!d.inRange) {
        cell.style.cssText = 'background:transparent;border-radius:8px;min-height:80px;';
        daysCol.appendChild(cell);
        return;
      }

      cell.className = 'cal-day-cell';
      cell.id = isToday ? 'today-anchor' : '';
      cell.style.cssText = `
        background:${isToday ? 'var(--highlight-soft)' : (isPast ? '#fafaf8' : 'white')};
        border:1.5px solid ${isToday ? 'var(--highlight)' : ts.border};
        border-radius:8px;
        overflow:hidden;
        min-height:80px;
        display:flex;
        flex-direction:column;
        opacity:${isPast && !isToday ? '0.65' : '1'};
      `;

      const hdr = document.createElement('div');
      hdr.className = 'cal-day-hdr';
      hdr.style.cssText = `
        padding:3px 6px;
        font-size:0.65rem;
        font-weight:700;
        color:${isToday ? 'var(--accent)' : 'var(--ink-light)'};
        border-bottom:1px solid ${isToday ? 'var(--highlight)' : ts.border};
        background:${isToday ? 'rgba(245,200,66,0.2)' : 'rgba(0,0,0,0.02)'};
        display:flex;
        justify-content:space-between;
        align-items:center;
      `;
      const dateNum = d.date.split(' ')[0];
      hdr.innerHTML = `<span>${dateNum}</span>${isToday ? '<span style="font-size:0.55rem;background:var(--accent);color:white;padding:1px 4px;border-radius:3px;">TODAY</span>' : ''}`;
      cell.appendChild(hdr);

      const body = document.createElement('div');
      body.className = 'cal-day-body';
      body.style.cssText = 'padding:4px;display:flex;flex-direction:column;gap:3px;flex:1;';

      if (visibleTasks.length === 0) {
        body.innerHTML = '<div class="cal-empty-day" style="flex:1;display:flex;align-items:center;justify-content:center;"><span style="font-size:0.6rem;color:var(--border);">—</span></div>';
      } else {
        visibleTasks.forEach(item => {
          const t = item.task;
          const done = item.done ? 'done' : '';
          const special = t.special === 'special' ? 'event-special' : t.special === 'school' ? 'event-school' : '';
          const sClass = special || subjClass(t.subj);
          const taskEl = document.createElement('button');
          taskEl.type = 'button';
          taskEl.className = `task-item ${sClass} ${done}`;
          taskEl.onclick = () => { toggleTask(item.key, taskEl); };

          let srcBadge = '';
          const isLiveExam = t.text.startsWith('⚠️');
          if (isLiveExam) {
            const examD = parseCalendarDate(d.date); examD.setHours(0,0,0,0);
            const todayD = new Date(); todayD.setHours(0,0,0,0);
            if (examD.getTime() === todayD.getTime()) {
              srcBadge = '<span style="font-size:0.5rem;background:#dc2626;color:white;padding:0 4px;border-radius:3px;margin-left:2px;flex-shrink:0;font-weight:700;animation:pulse 1s infinite;" title="Exam today!">LIVE</span>';
            } else if (examD < todayD) {
              srcBadge = '<span style="font-size:0.5rem;background:#e5f2eb;color:#1e6b3e;border:1px solid #a7d7b8;padding:0 3px;border-radius:3px;margin-left:2px;flex-shrink:0;" title="Exam done">✓</span>';
            } else {
              srcBadge = '<span style="font-size:0.5rem;background:#fee2e2;color:#991b1b;border:1px solid #fca5a5;padding:0 3px;border-radius:3px;margin-left:2px;flex-shrink:0;" title="Exam day">📝</span>';
            }
          } else if (t.src === 'holiday') {
            srcBadge = '<span style="font-size:0.5rem;background:#fef3e2;color:#92400e;border:1px solid #fcd34d;padding:0 3px;border-radius:3px;margin-left:2px;flex-shrink:0;" title="Holiday revision">🐣</span>';
          } else if (t.src === 'added') {
            srcBadge = '<span style="font-size:0.5rem;background:#e0f2fe;color:#0369a1;border:1px solid #7dd3fc;padding:0 3px;border-radius:3px;margin-left:2px;flex-shrink:0;" title="Added">+</span>';
          }
          taskEl.innerHTML = `<div class="task-cb"></div><span style="flex:1;min-width:0;text-align:left;">${t.text}</span>${srcBadge}`;
          body.appendChild(taskEl);
        });
      }
      cell.appendChild(body);
      weekRow.appendChild(cell);
    });

    container.appendChild(weekRow);
  });
}


function renderExams() {

  const container = document.getElementById('exam-lists-container');
  container.innerHTML = '';

  function makeList(title, badge, badgeClass, items, listKey) {
    const card = document.createElement('div');
    card.className = 'exam-list-card';
    let rows = items.map((name, i) => {
      const key = examKey(listKey, i);
      const done = state.exams[key] ? 'done' : '';
      const tick = done ? '✓' : '';
      return `
        <div class="exam-row ${done}" onclick="toggleExam('${key}', this)">
          <div class="exam-num">${i + 1}</div>
          <span class="exam-name">${name}</span>
          <div class="exam-tick">${tick}</div>
        </div>`;
    }).join('');

    card.innerHTML = `
      <div class="exam-list-header">
        ${title} <span class="badge ${badgeClass}">${badge}</span>
      </div>
      <div class="exam-list-body">${rows}</div>
    `;
    container.appendChild(card);
  }

  makeList('Before Half Term', 'Priority', 'badge-before', examsBefore, 'before');
  makeList('After Half Term', 'Coming up', 'badge-after', examsAfter, 'after');
}

// ─── INTERACTIONS ────────────────────────────────────────────────────────────

function toggleTask(key, el) {
  state.tasks[key] = !state.tasks[key];
  saveState();
  el.classList.toggle('done', state.tasks[key]);
  updateProgress();
  // update week stat labels
  renderTimetable();
}

function toggleExam(key, el) {
  state.exams[key] = !state.exams[key];
  saveState();
  el.classList.toggle('done', state.exams[key]);
  const tick = el.querySelector('.exam-tick');
  if (tick) tick.textContent = state.exams[key] ? '✓' : '';
  const num = el.querySelector('.exam-num');
  // keep num colour via css
  updateProgress();
}


function renderFilters() {
  const row = document.getElementById('subject-filter-row');
  if (!row) return;
  const subjects = [
    ['all', 'All'],
    ['maths', 'Maths'],
    ['lit', 'Lit'],
    ['english', 'Lang'],
    ['bio', 'Bio'],
    ['chem', 'Chem'],
    ['physics', 'Physics'],
    ['history', 'History'],
    ['geog', 'Geog'],
    ['art', 'Art'],
    ['music', 'Music']
  ];
  row.innerHTML = subjects.map(([key, label]) =>
    `<button class="filter-btn ${activeFilter === key ? 'active' : ''}" onclick="setSubjectFilter('${key}')">${label}</button>`
  ).join('');
  const doneBtn = document.getElementById('toggle-done-btn');
  if (doneBtn) doneBtn.classList.toggle('active', hideCompleted);
}

function setSubjectFilter(subject) {
  activeFilter = subject;
  renderFilters();
  renderTimetable();
  updateProgress();
}

function toggleHideDone() {
  hideCompleted = !hideCompleted;
  renderFilters();
  renderTimetable();
  updateProgress();
}

function jumpToToday() {
  const el = document.getElementById('today-anchor');
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function resetAllProgress() {
  if (!window.confirm('Reset all ticks and start fresh?')) return;
  state = { tasks: {}, exams: {} };
  saveState();
  examTableRendered = false;
  renderTimetable();
  renderExams();
  renderExamTable();
  updateProgress();
}

function getTaskStreak() {
  const doneEntries = getAllTaskEntries().filter(entry => entry.done);
  if (!doneEntries.length) return 0;
  const days = [...new Set(doneEntries.map(entry => entry.dateObj.toISOString().slice(0,10)))].sort().reverse();
  const today = new Date(); today.setHours(0,0,0,0);

  let streak = 0;
  let cursor = new Date(today);
  for (;;) {
    const key = cursor.toISOString().slice(0,10);
    if (days.includes(key)) {
      streak++;
      cursor.setDate(cursor.getDate() - 1);
    } else {
      break;
    }
  }
  return streak;
}

function renderDashboard() {
  const visibleEntries = getVisibleEntries();
  const title = document.getElementById('today-focus-title');
  const subtext = document.getElementById('today-focus-subtext');
  const focusList = document.getElementById('today-focus-list');
  const micro = document.getElementById('today-micro-stats');
  const visibleTaskCount = document.getElementById('visible-task-count');
  const visibleTaskCopy = document.getElementById('visible-task-copy');
  const streakCount = document.getElementById('streak-count');
  const nextExamCountdown = document.getElementById('next-exam-countdown');
  const nextExamCopy = document.getElementById('next-exam-copy');

  const today = new Date(); today.setHours(0,0,0,0);
  const todayEntries = visibleEntries.filter(entry => entry.dateObj.getTime() === today.getTime());
  const upcomingEntries = visibleEntries.filter(entry => entry.dateObj >= today).sort((a,b) => a.dateObj - b.dateObj);
  const overdueEntries = visibleEntries.filter(entry => entry.dateObj < today && !entry.done).sort((a,b) => b.dateObj - a.dateObj);

  let heroEntries = [];
  if (todayEntries.length) {
    title.textContent = 'Today is the main event.';
    subtext.textContent = 'Tackle these first so the plan stops shouting at you.';
    heroEntries = todayEntries;
  } else if (overdueEntries.length) {
    title.textContent = 'A couple of loose ends.';
    subtext.textContent = 'Not a disaster. Just clear the oldest overdue bits first.';
    heroEntries = overdueEntries.slice(0, 4);
  } else if (upcomingEntries.length) {
    const nextDate = upcomingEntries[0].day.date;
    title.textContent = 'Next up: ' + nextDate;
    subtext.textContent = 'Nothing due today, so here is the next stack coming down the track.';
    heroEntries = upcomingEntries.slice(0, 4);
  } else {
    title.textContent = 'Board looks clean.';
    subtext.textContent = 'Either everything is done or the filters are hiding it. Suspiciously efficient.';
    heroEntries = [];
  }

  micro.innerHTML = [
    `<span class="micro-pill">${activeFilter === 'all' ? 'All subjects' : activeFilter}</span>`,
    `<span class="micro-pill">${hideCompleted ? 'Completed hidden' : 'Completed visible'}</span>`,
    `<span class="micro-pill">${overdueEntries.length} overdue</span>`
  ].join('');

  if (!heroEntries.length) {
    focusList.innerHTML = '<div class="empty-focus">No visible tasks in this view. Flip the filter or enjoy the rare sensation of being caught up.</div>';
  } else {
    focusList.innerHTML = heroEntries.map(entry => {
      const when = entry.dateObj.getTime() === today.getTime() ? 'Today' : entry.day.date;
      const pill = entry.done ? 'Done' : when;
      return `<div class="focus-task">
        <div class="task-cb ${entry.done ? 'done' : ''}" style="${entry.done ? 'background:currentColor;color:white;' : ''}">${entry.done ? '✓' : ''}</div>
        <div style="flex:1;min-width:0;">
          <div style="font-weight:700;margin-bottom:3px;">${entry.task.text}</div>
          <div style="font-size:0.74rem;color:var(--ink-light);text-transform:uppercase;letter-spacing:0.05em;">${entry.task.subj || 'general'} · ${entry.week.label}</div>
        </div>
        <span class="pill">${pill}</span>
      </div>`;
    }).join('');
  }

  visibleTaskCount.textContent = String(visibleEntries.length);
  const undone = visibleEntries.filter(entry => !entry.done).length;
  visibleTaskCopy.textContent = `${undone} still to do in the current view.`;
  streakCount.textContent = String(getTaskStreak());

  const written = examTimetable.filter(e => !e.coursework);
  const nextExam = written.find(e => parseExamDate(e.date) >= today);
  if (nextExam) {
    const days = Math.round((parseExamDate(nextExam.date) - today) / 86400000);
    nextExamCountdown.textContent = days === 0 ? 'Today' : days === 1 ? '1 day' : `${days} days`;
    nextExamCopy.textContent = `${nextExam.subject} · ${nextExam.paper.replace(/\(.*?\)/g,'').trim()} · ${nextExam.date} 2026`;
  } else {
    nextExamCountdown.textContent = 'Done';
    nextExamCopy.textContent = 'No more written exams left in the timetable.';
  }
}

function updateProgress() {
  let total = 0, done = 0;
  weeks.forEach((week, wi) => {
    week.days.forEach((d, di) => {
      d.tasks.forEach((t, ti) => {
        total++;
        if (state.tasks[taskKey(wi, di, ti)]) done++;
      });
    });
  });
  const pct = total ? Math.round((done / total) * 100) : 0;
  document.getElementById('progress-fill').style.width = pct + '%';
  document.getElementById('progress-text').textContent = `${done} of ${total} tasks done`;
  document.getElementById('progress-pct').textContent = pct + '%';

  const startDate = new Date('2026-03-30');
  const endDate   = new Date('2026-06-15');
  const today     = new Date();
  today.setHours(0,0,0,0);

  let expectedPct = 0;
  if (today <= startDate) {
    expectedPct = 0;
  } else if (today >= endDate) {
    expectedPct = 100;
  } else {
    const elapsed = today - startDate;
    const span    = endDate - startDate;
    expectedPct   = Math.round((elapsed / span) * 100);
  }

  const delta = pct - expectedPct;
  let light, label;
  const endDateCmp = new Date(endDate); endDateCmp.setHours(0,0,0,0);
  const startDateCmp = new Date(startDate); startDateCmp.setHours(0,0,0,0);
  if (today >= endDateCmp) {
    light = pct === 100 ? '🟢' : pct >= 80 ? '🟡' : '🔴';
    label = pct === 100 ? 'Complete!' : 'Final stretch';
  } else if (today < startDateCmp) {
    light = '⚪';
    label = 'Not started yet';
  } else if (delta >= 5) {
    light = '🟢';
    label = 'Ahead of schedule';
  } else if (delta >= -10) {
    light = '🟡';
    label = 'On track';
  } else {
    light = '🔴';
    label = 'Needs a push';
  }

  document.getElementById('traffic-light').textContent = light;
  document.getElementById('traffic-label').textContent = label;

  renderDashboard();
}

function switchTab(name) {
  document.querySelectorAll('.tab').forEach((t, i) => {
    t.classList.toggle('active', ['timetable','exams','revision','examtable'][i] === name);
  });
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.getElementById(`panel-${name}`).classList.add('active');
  if (name === 'revision') renderSubjectGrid();
  if (name === 'examtable') { examTableRendered = false; renderExamTable(); }
}

// ─── REVISION PAGE ────────────────────────────────────────────────────────────

const subjects = [
  {
    id: 'maths', label: 'Maths', emoji: '📐',
    cards: [
      { q: 'Quadratic formula (Pearson Higher)', a: 'x = (−b ± √(b²−4ac)) / 2a\nOn Pearson you MUST show working. Formula given on sheet — but know when to use it.' },
      { q: 'How do you find the gradient of a line?', a: 'gradient = (y₂ − y₁) / (x₂ − x₁)\nAlso = m in y = mx + c' },
      { q: 'What is Pythagoras\'s theorem?', a: 'a² + b² = c²\nc is always the hypotenuse (longest side).' },
      { q: 'Area of a circle?', a: 'A = πr²\nCircumference = 2πr' },
      { q: 'What is a prime number?', a: 'A number with exactly 2 factors: 1 and itself.\nFirst primes: 2, 3, 5, 7, 11, 13...' },
      { q: 'How do you calculate percentage change?', a: '(New − Old) / Old × 100\nPositive = increase, negative = decrease.' },
      { q: 'What are the sine and cosine rules?', a: 'Sine: a/sinA = b/sinB\nCosine: a² = b² + c² − 2bc·cosA' },
      { q: 'How do you solve simultaneous equations by elimination?', a: 'Make coefficients of one variable equal, then add or subtract to eliminate it. Substitute back to find both values.' },
    ]
  },
  {
    id: 'lit', label: 'English Lit', emoji: '📖',
    cards: [
      { q: 'What does Macbeth\'s "Stars, hide your fires" reveal?', a: 'His ambition is so strong he wants darkness to conceal his murderous thoughts — showing his awareness of his own moral corruption.' },
      { q: 'What is the key theme of Power & Conflict poetry?', a: 'Poems explore how power — political, natural, personal — causes and results from conflict. Often shows the cost of war or oppression on individuals.' },
      { q: 'How does Shakespeare present Lady Macbeth as powerful?', a: '"Unsex me here" — she rejects femininity to pursue power. She manipulates Macbeth using his masculinity against him.' },
      { q: 'What technique is "Out, damned spot!"?', a: 'Exclamatory sentence + metaphor. Reveals her guilt and breakdown — the blood she cannot wash away symbolises her crime.' },
      { q: 'In unseen poetry, what should you analyse?', a: 'SMILE: Structure, Meaning, Imagery, Language, Effect on reader. Always link technique to effect and poet\'s intent.' },
      { q: 'What does "nothing will come of nothing" mean in King Lear / how does it link to Macbeth?', a: 'Macbeth\'s theme: ambition built on "nothing" (prophecy, illusion) leads to destruction. Compare to the witches\' equivocation.' },
      { q: 'Name 3 key Power & Conflict poems and their themes.', a: 'Ozymandias (pride & decay of power), Charge of the Light Brigade (futility of war), Exposure (nature vs soldiers, suffering).' },
      { q: 'How do you structure a literature essay paragraph?', a: 'Point → Evidence (quote) → Explain technique → Analyse effect → Link to theme/context (PEEL or similar).' },
    ]
  },
  {
    id: 'english', label: 'English Lang', emoji: '✍️',
    cards: [
      { q: 'What does a Q2 language question require?', a: 'Identify language techniques (metaphor, simile, personification etc.), quote accurately, and explain the effect on the reader. Don\'t just spot — analyse.' },
      { q: 'What is structural analysis (Q3)?', a: 'How the writer organises the whole text: openings, endings, shifts in focus, shifts in time, perspective, sentence structure patterns.' },
      { q: 'What makes a strong descriptive opening?', a: 'Drop the reader in — use the senses, avoid clichés, establish atmosphere immediately. Vary sentence length for effect.' },
      { q: 'What is a fronted adverbial?', a: 'An adverbial phrase at the start of a sentence: "In the darkness, she waited." Followed by a comma. Creates atmosphere or emphasis.' },
      { q: 'What techniques impress in narrative writing?', a: 'Varied sentence length, figurative language, show don\'t tell, strong verbs, controlled structure, an unexpected twist or circular ending.' },
      { q: 'What does Q4 (evaluation) ask you to do?', a: 'Do you agree with a statement about the text? Use evidence to support or challenge it. Show you can think critically about the writer\'s choices.' },
      { q: 'What is the difference between explicit and implicit meaning?', a: 'Explicit = stated directly. Implicit = suggested/implied — you have to infer it from the language or context.' },
      { q: 'Name 3 persuasive techniques (DAFOREST).', a: 'Direct address (you), Anecdote, Facts, Opinion, Rhetorical questions, Emotive language, Statistics, Triples (rule of three).' },
    ]
  },
  {
    id: 'bio', label: 'Biology', emoji: '🧬',
    cards: [
      { q: 'What is the difference between mitosis and meiosis?', a: 'Mitosis: produces 2 identical cells (growth/repair). Meiosis: produces 4 genetically different cells (reproduction/gametes).' },
      { q: 'What is a limiting factor in photosynthesis?', a: 'Light intensity, CO₂ concentration, temperature. Whichever is lowest limits the rate even if others increase.' },
      { q: 'What do enzymes do and what affects them?', a: 'Biological catalysts that speed up reactions. Affected by temperature and pH — denature if too high.' },
      { q: 'Aerobic respiration equation (AQA)', a: 'Glucose + Oxygen → Carbon dioxide + Water\nAQA also test anaerobic: Glucose → Lactic acid (animals) or Glucose → Ethanol + CO₂ (yeast)' },
      { q: 'How does the immune system respond to pathogens?', a: 'White blood cells: phagocytes engulf pathogens; lymphocytes produce antibodies specific to antigens. Memory cells enable faster future response.' },
      { q: 'What is homeostasis?', a: 'Maintaining a stable internal environment (e.g. body temperature 37°C, blood glucose levels) despite external changes.' },
      { q: 'What is natural selection?', a: 'Organisms with favourable variations survive, reproduce, and pass on traits. Over time, population adapts to environment (Darwin).' },
      { q: 'What is the difference between dominant and recessive alleles?', a: 'Dominant (capital letter) always expressed if present. Recessive (lowercase) only expressed if homozygous (two copies).' },
    ]
  },
  {
    id: 'chem', label: 'Chemistry', emoji: '⚗️',
    cards: [
      { q: 'What is the difference between ionic and covalent bonding?', a: 'Ionic: transfer of electrons between metal and non-metal (forms ions). Covalent: sharing of electrons between non-metals.' },
      { q: 'What is a mole?', a: '6.02 × 10²³ particles. Moles = mass (g) ÷ relative formula mass (Mr).' },
      { q: 'What affects the rate of a chemical reaction?', a: 'Temperature, concentration, surface area, catalyst, pressure (gases). All increase collision frequency or energy.' },
      { q: 'What is the difference between exothermic and endothermic?', a: 'Exothermic: releases energy (temperature rises) e.g. combustion. Endothermic: absorbs energy (temperature falls) e.g. thermal decomposition.' },
      { q: 'What is oxidation and reduction (OILRIG)?', a: 'OIL: Oxidation Is Loss (of electrons). RIG: Reduction Is Gain (of electrons). Happens simultaneously in redox reactions.' },
      { q: 'What are the properties of Group 1 metals?', a: 'Soft, low density, react vigorously with water (producing H₂ and metal hydroxide). Reactivity increases down the group.' },
      { q: 'AQA required practical: tests for gases', a: 'CO₂: limewater turns cloudy. O₂: relights glowing splint. H₂: squeaky pop with lit splint. Cl₂: bleaches damp litmus.' },
      { q: 'What is the structure of an atom?', a: 'Nucleus (protons + neutrons) surrounded by electrons in shells. Atomic number = protons. Mass number = protons + neutrons.' },
    ]
  },
  {
    id: 'physics', label: 'Physics', emoji: '⚡',
    cards: [
      { q: 'What is Newton\'s Second Law?', a: 'Force = mass × acceleration (F = ma)\nForce in Newtons, mass in kg, acceleration in m/s².' },
      { q: 'What is the equation for wave speed?', a: 'wave speed = frequency × wavelength\nv = fλ (m/s = Hz × m)' },
      { q: 'What is the difference between series and parallel circuits?', a: 'Series: same current throughout, voltage splits. Parallel: voltage same across branches, current splits.' },
      { q: 'What is the equation for kinetic energy?', a: 'KE = ½mv²\nm = mass (kg), v = velocity (m/s). Energy in Joules.' },
      { q: 'What is the difference between nuclear fission and fusion?', a: 'Fission: heavy nucleus splits (used in reactors). Fusion: light nuclei join (powers stars). Both release huge energy.' },
      { q: 'What is Hooke\'s Law?', a: 'Force = spring constant × extension (F = ke)\nOnly applies in the elastic limit — beyond that, spring deforms permanently.' },
      { q: 'What is specific heat capacity?', a: 'Energy needed to raise 1 kg of a substance by 1°C.\nE = mcΔθ (Joules = kg × J/kg°C × °C)' },
      { q: 'What is the difference between transverse and longitudinal waves?', a: 'Transverse: oscillation perpendicular to direction (e.g. light). Longitudinal: oscillation parallel to direction (e.g. sound).' },
    ]
  },
  {
    id: 'history', label: 'History', emoji: '🏛️',
    cards: [
      { q: 'Push/pull factors for migration to Britain (Pearson 1HI0 13)', a: 'Push: war, persecution, famine, poverty. Pull: work, Empire ties, safety, better living. Key waves: Jewish 1880s/1930s, Windrush 1948, South Asian 1960s–70s.' },
      { q: 'What were the main threats to Elizabethan England?', a: 'Catholic plots (Ridolfi, Throckmorton, Babington), Mary Queen of Scots, Spanish Armada 1588, poverty and vagrancy.' },
      { q: 'What caused the Arab-Israeli conflict? (Pearson)', a: 'Balfour Declaration 1917, British Mandate, creation of Israel 1948, Arab-Israeli War, Palestinian displacement. Key dates: 1948, 1967 Six Day War, 1973 Yom Kippur War.' },
      { q: 'What was the significance of the 1967 Six Day War?', a: 'Israel captured West Bank, Gaza, Sinai, Golan Heights. Massively expanded territory. Created ongoing occupation issues still unresolved.' },
      { q: 'Key features of Elizabethan society?', a: 'Strict social hierarchy, patriarchal, Protestant Church of England, fear of Catholic plots, flourishing arts (Shakespeare), exploration (Drake).' },
      { q: 'How do you write a strong history essay?', a: 'Clear argument in intro, evidence with specific dates/names, explain significance, acknowledge counterargument, strong conclusion that directly answers the question.' },
      { q: 'What was the significance of the Spanish Armada (1588)?', a: 'Philip II\'s attempt to invade England failed. English victory due to weather, tactics (fireships at Gravelines). Boosted Elizabeth\'s prestige enormously.' },
      { q: 'What was the impact of WW2 migration on Britain?', a: 'Windrush generation (1948) filled labour shortages. Faced discrimination (No Blacks signs). Led to Race Relations Acts. Shaped multicultural Britain.' },
    ]
  },
  {
    id: 'geog', label: 'Geography', emoji: '🌍',
    cards: [
      { q: 'What is the difference between a earthquake\'s focus and epicentre?', a: 'Focus: point underground where earthquake originates. Epicentre: point on the surface directly above the focus — greatest damage here.' },
      { q: 'Name a case study for a tropical rainforest and key facts.', a: 'Amazon Rainforest: 5.5 million km², 10% of world\'s species, deforestation for cattle ranching/soy. Threats: logging, mining, road building.' },
      { q: 'What causes tropical storms (hurricanes/typhoons)?', a: 'Warm ocean water (>27°C) evaporates, rises, cools, condenses. Releases latent heat, air rises faster, low pressure develops, winds spiral inward.' },
      { q: 'What is the demographic transition model?', a: '5 stages from high birth+death rates to low both. Stage 1: pre-industrial. Stage 5: declining population. UK is Stage 4/5.' },
      { q: 'What is urban sprawl and what causes it?', a: 'Uncontrolled outward growth of cities into rural areas. Causes: population growth, suburbanisation, cheaper land, car ownership.' },
      { q: 'What is the difference between an HIC and LIC?', a: 'HIC: High Income Country (e.g. UK, USA) — high GDP, services economy. LIC: Low Income Country (e.g. Chad) — low GDP, agriculture-dependent.' },
      { q: 'What are the effects of river flooding?', a: 'Social: deaths, displacement. Economic: property damage, business loss. Environmental: water/soil contamination, ecosystem disruption.' },
      { q: 'What is a composite volcano (stratovolcano)?', a: 'Steep-sided, made of alternating lava and ash layers. Found at destructive plate margins. Explosive eruptions. E.g. Mount Etna, Vesuvius.' },
    ]
  },
  {
    id: 'art', label: 'Art', emoji: '🎨',
    cards: [
      { q: 'What are the 4 GCSE Art assessment objectives?', a: 'AO1: Develop ideas through artists/sources. AO2: Refine work using skills/techniques. AO3: Record observations. AO4: Personal response.' },
      { q: 'How should you annotate sketchbook work?', a: 'Describe what you did, why you chose it, what worked/didn\'t, what you\'d change, how it links to an artist or theme. Be specific.' },
      { q: 'How do you write about an artist\'s influence?', a: 'Name + context → describe their technique → show how you applied it → explain why it suits your theme. Include a visual link.' },
      { q: 'What should your exam day personal response include?', a: 'Clear link to your theme, evidence of AO1–AO4 across the work, refinement from the preparatory period, strong composition and technique.' },
      { q: 'What is tone and how do you show it?', a: 'Range from light to dark. Show with hatching, cross-hatching, blending, stippling. Creates depth, form and atmosphere.' },
      { q: 'What is the difference between primary and secondary sources?', a: 'Primary: direct observation (life drawing, own photography). Secondary: found images, other artists\' work. Both should be in sketchbook.' },
    ]
  },
  {
    id: 'music', label: 'Music', emoji: '🎵',
    cards: [
      { q: 'What does MADTSHIRT stand for?', a: 'Melody, Articulation, Dynamics, Tempo, Structure, Harmony, Instrumentation/Texture, Rhythm, Tonality. The musical elements for analysis.' },
      { q: 'What is a cadence and name the types?', a: 'A harmonic ending. Perfect: V→I (strong close). Imperfect: ends on V (unfinished). Plagal: IV→I (church). Interrupted: V→any not I (surprise).' },
      { q: 'What is the difference between homophonic and polyphonic texture?', a: 'Homophonic: melody + chords/accompaniment (most pop). Polyphonic: two or more independent melodic lines (e.g. Bach fugue).' },
      { q: 'What is modulation?', a: 'Changing key within a piece. Common in classical music — often to the dominant (5th above). Creates tension and contrast.' },
      { q: 'How do you approach a listening exam question?', a: 'Listen once for overview. Second time: focus on what\'s asked (rhythm, texture, instruments). Use correct musical vocabulary. Be specific.' },
      { q: 'What is the difference between major and minor tonality?', a: 'Major: bright, happy sound. Minor: darker, sadder sound. Determined by the third note of the scale (major 3rd vs minor 3rd).' },
      { q: 'What is syncopation?', a: 'Accenting the off-beat rather than the main beat. Common in jazz, funk, and much pop music. Creates rhythmic energy and groove.' },
      { q: 'What is a leitmotif?', a: 'A recurring musical theme associated with a character, place, or idea. Used by composers like Wagner and film composers like John Williams.' },
    ]
  },
];

let activeSubject = null;
let currentCardIndex = 0;
let cardFlipped = false;

function renderSubjectGrid() {
  const grid = document.getElementById('subject-grid');
  if (grid.innerHTML) return;
  subjects.forEach(s => {
    const card = document.createElement('div');
    card.style.cssText = `cursor:pointer;background:white;border:1.5px solid var(--border);border-radius:10px;padding:18px 14px;display:flex;flex-direction:column;gap:8px;transition:box-shadow 0.15s;`;
    card.innerHTML = `
      <div style="font-size:1.8rem;">${s.emoji}</div>
      <div style="font-weight:600;font-size:0.9rem;">${s.label}</div>
      <div style="font-size:0.72rem;color:var(--ink-light);">${s.cards.length} flashcards</div>
    `;
    card.onmouseenter = () => card.style.boxShadow = '0 4px 16px rgba(0,0,0,0.09)';
    card.onmouseleave = () => card.style.boxShadow = 'none';
    card.onclick = () => openSubject(s);
    grid.appendChild(card);
  });
}

function openSubject(s) {
  activeSubject = s;
  currentCardIndex = 0;
  cardFlipped = false;
  document.getElementById('revision-home').style.display = 'none';
  document.getElementById('revision-detail').style.display = 'block';
  renderFlashcards();
}

function renderFlashcards() {
  const s = activeSubject;
  const inner = document.getElementById('revision-detail-inner');
  inner.innerHTML = `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px;flex-wrap:wrap;">
      <span style="font-size:2rem;">${s.emoji}</span>
      <h2 style="font-family:'DM Serif Display',serif;font-size:1.6rem;flex:1;">${s.label} Flashcards</h2>
      <span style="font-size:0.78rem;color:var(--ink-light);background:var(--surface);border:1px solid var(--border);padding:4px 12px;border-radius:99px;" id="card-counter">1 / ${s.cards.length}</span>
    </div>

    <style>
      .flashcard-scene { width:100%;max-width:580px;margin:0 auto 24px;height:220px;perspective:1000px;cursor:pointer; }
      .flashcard-inner { position:relative;width:100%;height:100%;transition:transform 0.5s;transform-style:preserve-3d; }
      .flashcard-scene.flipped .flashcard-inner { transform:rotateY(180deg); }
      .flashcard-face { position:absolute;width:100%;height:100%;backface-visibility:hidden;border-radius:14px;display:flex;align-items:center;justify-content:center;padding:28px;text-align:center; }
      .flashcard-front { background:var(--ink);color:white;box-shadow:0 8px 32px rgba(0,0,0,0.18); }
      .flashcard-back { background:var(--green-soft);border:2px solid var(--green);transform:rotateY(180deg); }
      .flashcard-front .label { font-size:0.68rem;text-transform:uppercase;letter-spacing:0.1em;opacity:0.5;margin-bottom:14px; }
      .flashcard-front .question { font-family:'DM Serif Display',serif;font-size:1.25rem;line-height:1.4; }
      .flashcard-back .answer { font-size:0.9rem;line-height:1.6;color:var(--ink);white-space:pre-line; }
      .fc-hint { font-size:0.72rem;color:var(--ink-light);text-align:center;margin-bottom:20px; }
      .fc-nav { display:flex;align-items:center;justify-content:center;gap:12px; }
      .fc-btn { background:white;border:1.5px solid var(--border);border-radius:8px;padding:9px 20px;font-family:'DM Sans',sans-serif;font-size:0.82rem;cursor:pointer;font-weight:500;transition:all 0.15s; }
      .fc-btn:hover { background:var(--ink);color:white;border-color:var(--ink); }
      .fc-btn:disabled { opacity:0.3;cursor:default; }
      .fc-dots { display:flex;gap:5px;align-items:center; }
      .fc-dot { width:7px;height:7px;border-radius:50%;background:var(--border); }
      .fc-dot.active { background:var(--ink); }
    </style>

    <div class="fc-hint">👆 Click the card to reveal the answer</div>

    <div class="flashcard-scene" id="flashcard-scene" onclick="flipCard()">
      <div class="flashcard-inner">
        <div class="flashcard-face flashcard-front">
          <div>
            <div class="label">Question ${currentCardIndex + 1}</div>
            <div class="question" id="fc-question">${s.cards[currentCardIndex].q}</div>
          </div>
        </div>
        <div class="flashcard-face flashcard-back">
          <div class="answer" id="fc-answer">${s.cards[currentCardIndex].a}</div>
        </div>
      </div>
    </div>

    <div class="fc-nav">
      <button class="fc-btn" id="fc-prev" onclick="prevCard()" ${currentCardIndex === 0 ? 'disabled' : ''}>← Prev</button>
      <div class="fc-dots" id="fc-dots"></div>
      <button class="fc-btn" id="fc-next" onclick="nextCard()" ${currentCardIndex === s.cards.length - 1 ? 'disabled' : ''}>Next →</button>
    </div>
  `;
  renderDots();
}

function renderDots() {
  const s = activeSubject;
  const dots = document.getElementById('fc-dots');
  if (!dots) return;
  dots.innerHTML = s.cards.map((_, i) =>
    `<div class="fc-dot ${i === currentCardIndex ? 'active' : ''}"></div>`
  ).join('');
}

function flipCard() {
  cardFlipped = !cardFlipped;
  const scene = document.getElementById('flashcard-scene');
  if (scene) scene.classList.toggle('flipped', cardFlipped);
}

function nextCard() {
  if (currentCardIndex < activeSubject.cards.length - 1) {
    currentCardIndex++;
    cardFlipped = false;
    updateCard();
  }
}

function prevCard() {
  if (currentCardIndex > 0) {
    currentCardIndex--;
    cardFlipped = false;
    updateCard();
  }
}

function updateCard() {
  const s = activeSubject;
  const scene = document.getElementById('flashcard-scene');
  const q = document.getElementById('fc-question');
  const a = document.getElementById('fc-answer');
  const counter = document.getElementById('card-counter');
  const prev = document.getElementById('fc-prev');
  const next = document.getElementById('fc-next');
  if (!scene || !q) return;
  scene.classList.remove('flipped');
  setTimeout(() => {
    q.textContent = s.cards[currentCardIndex].q;
    a.textContent = s.cards[currentCardIndex].a;
    if (counter) counter.textContent = `${currentCardIndex + 1} / ${s.cards.length}`;
    if (prev) prev.disabled = currentCardIndex === 0;
    if (next) next.disabled = currentCardIndex === s.cards.length - 1;
    renderDots();
  }, 260);
}

function backToSubjects() {
  document.getElementById('revision-home').style.display = 'block';
  document.getElementById('revision-detail').style.display = 'none';
}


// ─── EXAM TIMETABLE ──────────────────────────────────────────────────────────

const examTimetable = [
  { date: 'Thu 7 May',  time: 'TBC',   subject: 'English Language', paper: 'Spoken Language (8700/C)',              board: 'AQA',     coursework: true  },
  { date: 'Mon 11 May', time: '09:00', subject: 'English Lit',      paper: 'Paper 1 (8702/1)',                      board: 'AQA',     duration: '1h 45m' },
  { date: 'Tue 12 May', time: '13:30', subject: 'Biology',          paper: 'Paper 1 Tier H (8461/1H)',              board: 'AQA',     duration: '1h 45m' },
  { date: 'Wed 13 May', time: '09:00', subject: 'Geography',        paper: 'Paper 1 (8035/1)',                      board: 'AQA',     duration: '1h 30m' },
  { date: 'Thu 14 May', time: '09:00', subject: 'Maths',            paper: 'Non Calculator H (1MA1 1H)',            board: 'Pearson', duration: '1h 30m' },
  { date: 'Fri 15 May', time: 'TBC',   subject: 'Music',            paper: 'Performing (1MU0 01)',                  board: 'Pearson', coursework: true  },
  { date: 'Fri 15 May', time: 'TBC',   subject: 'Music',            paper: 'Composing (1MU0 02)',                   board: 'Pearson', coursework: true  },
  { date: 'Fri 15 May', time: '09:00', subject: 'History',          paper: 'Migrants in Britain (1HI0 13)',         board: 'Pearson', duration: '1h 20m' },
  { date: 'Mon 18 May', time: '09:00', subject: 'Chemistry',        paper: 'Paper 1 Tier H (8462/1H)',              board: 'AQA',     duration: '1h 45m' },
  { date: 'Tue 19 May', time: '09:00', subject: 'English Lit',      paper: 'Paper 2 (8702/2)',                      board: 'AQA',     duration: '2h 15m' },
  { date: 'Thu 21 May', time: '09:00', subject: 'English Language', paper: 'Paper 1 (8700/1)',                      board: 'AQA',     duration: '1h 45m' },
  { date: 'Sun 31 May', time: 'TBC',   subject: 'Art & Design',     paper: 'Fine Art Portfolio (8202/C)',           board: 'AQA',     coursework: true  },
  { date: 'Sun 31 May', time: 'TBC',   subject: 'Art & Design',     paper: 'Fine Art Externally Set (8202/X)',      board: 'AQA',     duration: '10h 00m' },
  { date: 'Tue 2 Jun',  time: '09:00', subject: 'Physics',          paper: 'Paper 1 Tier H (8463/1H)',              board: 'AQA',     duration: '1h 45m' },
  { date: 'Wed 3 Jun',  time: '09:00', subject: 'Maths',            paper: 'Calculator H (1MA1 2H)',                board: 'Pearson', duration: '1h 30m' },
  { date: 'Wed 3 Jun',  time: '13:30', subject: 'Geography',        paper: 'Paper 2 (8035/2)',                      board: 'AQA',     duration: '1h 30m' },
  { date: 'Thu 4 Jun',  time: '09:00', subject: 'History',          paper: 'Middle East & Elizabethan (1HI0 2W)',   board: 'Pearson', duration: '1h 50m' },
  { date: 'Thu 4 Jun',  time: '09:00', subject: 'History',          paper: 'Early Elizabethan (1HI0 B4)',           board: 'Pearson', duration: '-'      },
  { date: 'Thu 4 Jun',  time: '09:00', subject: 'History',          paper: 'Middle East (1HI0 P5)',                 board: 'Pearson', duration: '-'      },
  { date: 'Fri 5 Jun',  time: '09:00', subject: 'English Language', paper: 'Paper 2 (8700/2)',                      board: 'AQA',     duration: '1h 45m' },
  { date: 'Fri 5 Jun',  time: '13:30', subject: 'Music',            paper: 'Appraising (1MU0 03)',                  board: 'Pearson', duration: '1h 45m' },
  { date: 'Mon 8 Jun',  time: '09:00', subject: 'Biology',          paper: 'Paper 2 Tier H (8461/2H)',              board: 'AQA',     duration: '1h 45m' },
  { date: 'Tue 9 Jun',  time: '13:30', subject: 'History',          paper: 'The USA (1HI0 33)',                     board: 'Pearson', duration: '1h 30m' },
  { date: 'Wed 10 Jun', time: '09:00', subject: 'Maths',            paper: 'Calculator H (1MA1 3H)',                board: 'Pearson', duration: '1h 30m' },
  { date: 'Thu 11 Jun', time: '09:00', subject: 'Geography',        paper: 'Paper 3 (8035/3)',                      board: 'AQA',     duration: '1h 30m' },
  { date: 'Fri 12 Jun', time: '09:00', subject: 'Chemistry',        paper: 'Paper 2 Tier H (8462/2H)',              board: 'AQA',     duration: '1h 45m' },
  { date: 'Mon 15 Jun', time: '09:00', subject: 'Physics',          paper: 'Paper 2 Tier H (8463/2H)',              board: 'AQA',     duration: '1h 45m' },
];

const etColors = {
  'English Language': { bg: '#fce8f3', color: '#9d174d', border: '#f8b4d9' },
  'English Lit':      { bg: '#fce8f3', color: '#9d174d', border: '#f8b4d9' },
  'Biology':          { bg: '#e5f2eb', color: '#1e6b3e', border: '#a7d7b8' },
  'Geography':        { bg: '#e5f7f0', color: '#1a6b50', border: '#8ad4b8' },
  'Maths':            { bg: '#e8f0fe', color: '#1a56db', border: '#c3d4fa' },
  'Music':            { bg: '#fdf5e8', color: '#7a4e00', border: '#f5d498' },
  'History':          { bg: '#fdf0e3', color: '#8a4a00', border: '#f5c88a' },
  'Chemistry':        { bg: '#e5f0fa', color: '#1c4a8a', border: '#a9c8ef' },
  'Physics':          { bg: '#e8f7ff', color: '#0e5c8a', border: '#90d2f0' },
  'Art & Design':     { bg: '#f5e8ff', color: '#6a1e9e', border: '#d4a8f5' },
};

function parseExamDate(dateStr) {
  const months = {Jan:0,Feb:1,Mar:2,Apr:3,May:4,Jun:5,Jul:6,Aug:7,Sep:8,Oct:9,Nov:10,Dec:11};
  const parts = dateStr.trim().split(' ');
  const day = parseInt(parts[1]);
  const mon = months[parts[2]];
  return new Date(2026, mon, day);
}

let examTableRendered = false;

function renderExamTable() {
  if (examTableRendered) return;
  examTableRendered = true;

  const container = document.getElementById('examtable-container');
  const today = new Date(); today.setHours(0,0,0,0);

  const written = examTimetable.filter(e => !e.coursework);
  const upcoming = written.filter(e => parseExamDate(e.date) >= today).length;
  const done = written.filter(e => parseExamDate(e.date) < today).length;
  const nextExam = written.find(e => parseExamDate(e.date) >= today);
  const daysToNext = nextExam ? Math.round((parseExamDate(nextExam.date) - today) / 86400000) : null;

  // Build summary bar
  let html = '<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:28px;">';
  html += '<div style="background:white;border:1.5px solid var(--border);border-radius:10px;padding:14px 20px;flex:1;min-width:110px;"><div style="font-family:\'DM Serif Display\',serif;font-size:2rem;line-height:1;">' + upcoming + '</div><div style="font-size:0.7rem;color:var(--ink-light);text-transform:uppercase;letter-spacing:0.06em;margin-top:4px;">Ahead</div></div>';
  html += '<div style="background:var(--green-soft);border:1.5px solid var(--green);border-radius:10px;padding:14px 20px;flex:1;min-width:110px;"><div style="font-family:\'DM Serif Display\',serif;font-size:2rem;line-height:1;color:var(--green);">' + done + '</div><div style="font-size:0.7rem;color:var(--green);text-transform:uppercase;letter-spacing:0.06em;margin-top:4px;">Done</div></div>';
  if (nextExam) {
    const dl = daysToNext === 0 ? 'TODAY' : daysToNext === 1 ? 'Tomorrow' : daysToNext + ' days';
    html += '<div style="background:var(--ink);border-radius:10px;padding:14px 20px;flex:3;min-width:200px;display:flex;align-items:center;gap:16px;">';
    html += '<div style="font-family:\'DM Serif Display\',serif;font-size:2rem;line-height:1;color:var(--highlight);white-space:nowrap;">' + dl + '</div>';
    html += '<div><div style="color:white;font-size:0.85rem;font-weight:600;">' + nextExam.subject + '</div><div style="color:rgba(255,255,255,0.55);font-size:0.75rem;margin-top:2px;">' + nextExam.paper.replace(/\(.*?\)/g,'').trim() + ' · ' + nextExam.date + ' 2026</div></div>';
    html += '</div>';
  }
  html += '</div>';

  // Group exams by month
  const groups = {};
  examTimetable.forEach(e => {
    const mo = e.date.split(' ')[2];
    if (!groups[mo]) groups[mo] = [];
    groups[mo].push(e);
  });

  const monthOrder = ['May','Jun'];
  monthOrder.forEach(mo => {
    if (!groups[mo]) return;
    html += '<div style="margin-bottom:32px;">';
    html += '<div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">';
    html += '<h3 style="font-family:\'DM Serif Display\',serif;font-size:1.3rem;">' + mo + ' 2026</h3>';
    html += '<div style="flex:1;height:1px;background:var(--border);"></div>';
    html += '</div>';
    html += '<div style="display:flex;flex-direction:column;gap:8px;">';

    let lastDate = '';
    groups[mo].forEach(e => {
      const c2 = etColors[e.subject] || { bg: '#f5f5f5', color: '#444', border: '#ddd' };
      const examDate = parseExamDate(e.date);
      const isPast = examDate < today;
      const isToday = examDate.getTime() === today.getTime();

      const isNewDate = e.date !== lastDate;
      lastDate = e.date;

      const rowStyle = [
        'display:flex',
        'align-items:stretch',
        'gap:0',
        'border-radius:10px',
        'overflow:hidden',
        'border:1.5px solid ' + (isToday ? 'var(--highlight)' : 'var(--border)'),
        'opacity:' + (isPast ? '0.4' : '1'),
        'background:' + (isToday ? 'var(--highlight-soft)' : 'white'),
        'transition:box-shadow 0.15s',
      ].join(';');

      // Date column
      const dateStr = isNewDate ? e.date.split(' ').slice(0,2).join(' ') : '';
      const yearStr = isNewDate ? '2026' : '';

      html += '<div style="' + rowStyle + '">';

      // Left accent bar
      html += '<div style="width:5px;background:' + c2.color + ';flex-shrink:0;"></div>';

      // Date block
      html += '<div style="width:80px;flex-shrink:0;padding:12px 10px;display:flex;flex-direction:column;align-items:center;justify-content:center;border-right:1px solid var(--border);background:' + (isToday ? 'rgba(245,200,66,0.15)' : '#fafaf8') + ';">';
      if (isNewDate) {
        const dp = e.date.split(' ');
        html += '<div style="font-size:1.4rem;font-family:\'DM Serif Display\',serif;line-height:1;color:var(--ink);">' + dp[1] + '</div>';
        html += '<div style="font-size:0.68rem;font-weight:600;text-transform:uppercase;letter-spacing:0.06em;color:var(--ink-light);">' + dp[0] + ' ' + dp[2] + '</div>';
      }
      html += '</div>';

      // Time block
      html += '<div style="width:64px;flex-shrink:0;padding:12px 8px;display:flex;flex-direction:column;align-items:center;justify-content:center;border-right:1px solid var(--border);">';
      if (e.coursework) {
        html += '<div style="font-size:0.6rem;text-align:center;background:#f0f0f0;padding:3px 5px;border-radius:4px;color:#666;line-height:1.3;">Course-<br>work</div>';
      } else {
        html += '<div style="font-size:0.85rem;font-weight:600;color:var(--ink);">' + e.time + '</div>';
      }
      html += '</div>';

      // Subject + paper
      html += '<div style="flex:1;padding:12px 14px;display:flex;flex-direction:column;justify-content:center;min-width:0;">';
      html += '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:3px;">';
      html += '<span style="background:' + c2.bg + ';color:' + c2.color + ';border:1px solid ' + c2.border + ';padding:2px 9px;border-radius:5px;font-size:0.72rem;font-weight:600;white-space:nowrap;">' + e.subject + '</span>';
      if (isToday) html += '<span style="background:var(--highlight);color:#7a5800;padding:2px 8px;border-radius:5px;font-size:0.68rem;font-weight:700;">TODAY</span>';
      html += '</div>';
      html += '<div style="font-size:0.8rem;color:var(--ink-light);">' + e.paper + '</div>';
      html += '</div>';

      // Board + duration
      html += '<div style="flex-shrink:0;padding:12px 14px;display:flex;flex-direction:column;align-items:flex-end;justify-content:center;gap:4px;">';
      html += '<span style="font-size:0.7rem;background:var(--bg);border:1px solid var(--border);padding:2px 7px;border-radius:4px;color:var(--ink-light);">' + e.board + '</span>';
      html += '<span style="font-size:0.75rem;color:var(--ink-light);">' + (e.coursework ? '—' : (e.duration || '—')) + '</span>';
      html += '</div>';

      html += '</div>';
    });

    html += '</div></div>';
  });

  html += '<p style="font-size:0.72rem;color:var(--ink-light);margin-top:8px;">* Coursework/portfolio submissions — confirm exact dates with school. Source: Bristol Cathedral Choir School timetable, Francis Grindle.</p>';

  container.innerHTML = html;
}

// ─── INIT ────────────────────────────────────────────────────────────────────

renderFilters();
renderTimetable();
renderExams();
updateProgress();